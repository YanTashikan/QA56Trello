package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class ProfilesVisibilityHelper extends PageBase {

    public ProfilesVisibilityHelper(WebDriver driver) {
        super(driver);
    }
    @FindBy (xpath = "//button[contains(text(),'Save')]")
    WebElement saveBtN;
    @FindBy(xpath = "//button[@data-test-id = 'header-member-menu-button']")
    WebElement headerMemberMenuButton;
    @FindBy(xpath = "//a[@data-test-id = 'header-member-menu-profile']")
    WebElement headerMemberMenuProfileLink;
    //@FindBy(xpath = "//a[@data-test-id = 'header-member-menu-profile']") WebElement profileVisabilityMenu;



    public void openUpRightMenu(){
        headerMemberMenuButton.click();
        waitUntilElementIsVisible(headerMemberMenuProfileLink,10);
    }

    public void openProfileAndVisabilityMenu(){
        headerMemberMenuProfileLink.click();
        waitUntilAllElementsAreVisible(headerMemberMenuButton,20);
        waitUntilElementIsClickable(saveBtN,10);
    }

    public String getUserNameAfterShtrudel(){
        return driver.findElement(By.xpath("//span[contains(text(),'@')]")).getText();
    }

    public String getUserNameFieldText(){
        return driver.findElement(By.xpath("//input[@name='username']")).getAttribute("value");
    }

    public String getRightMenuText(){
        WebElement upRightMenu = driver.findElement(By.xpath("//button[@data-test-id = 'header-member-menu-button']"));
        return upRightMenu.findElement(By.xpath(".//span")).getText();
    }

    public int getIndexIcon(String username){
        //--- Receive list of necessary icons ---
        List<WebElement> iconsList = driver.findElements(By.xpath(createLocatorIconlist(username)));
        int counter = 0;
        for(WebElement element: iconsList)
            if (element.getText().equals(this.getRightMenuText())) counter++;

        return counter;
    }

    private String createLocatorIconlist(String username) {
        return "//div[@title='" + username + " (" + username + ")']//span";
    }

}
