package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BoardsPageHelper extends PageBase {
    public BoardsPageHelper(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//button[@data-test-id='header-boards-menu-button']/span[2]")
    WebElement headerBoardsMenuButton;
    @FindBy(xpath = "//button[@data-test-id='header-boards-menu-button']/span[2]")
    WebElement boardIcon;


    public void waitUntilPageIsLoaded() {
        waitUntilElementIsClickable(headerBoardsMenuButton,40);
    }

    public String getButtonBoardsText(){
        return boardIcon.getText();
    }
}
