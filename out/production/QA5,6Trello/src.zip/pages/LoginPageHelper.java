package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPageHelper extends PageBase{

    public LoginPageHelper(WebDriver driver){
        super(driver);
    }
    @FindBy(linkText = "Log In") WebElement loginLink;
    @FindBy(id = "login") WebElement loginBtn;
    @FindBy(id = "login-submit") WebElement loginSubmit;
    @FindBy(css = "#error>p") WebElement errorMsg;
    @FindBy(xpath = "//div[@id='login-error']//span") WebElement errorMsgAtlassian;

    public void openLoginPage(){
        loginLink.click();
        waitUntilElementIsClickable(loginBtn,10);
    }

    public void enterLoginAtlassianAndClickLogin(String login) {
        driver.findElement(By.id("user")).sendKeys(login);
        waitUntilAttributeValueIs(By.id("login"),"value","Log in with Atlassian",10);
        driver.findElement(By.id("login")).click();

        waitUntilElementIsClickable(loginSubmit,15);
    }

    public void enterPasswordAtlassionAndClickLogin(String password) {
        driver.findElement(By.id("password")).sendKeys(password);
        driver.findElement(By.id("login-submit")).click();
    }

    public void enterPassword(String password) {
        driver.findElement(By.id("password")).sendKeys(password);
    }

    public void enterLogin(String login) {
        driver.findElement(By.id("user")).sendKeys(login);
    }



    public void loginAsAtlassian(String login, String password){
        this.enterLoginAtlassianAndClickLogin(login);
        this.enterPasswordAtlassionAndClickLogin(password);
    }


    public void pressLoginButton() {
        driver.findElement(By.id("login")).click();
    }

    public void waitErrorMessage() {
        waitUntilElementIsVisible(errorMsg,10);
    }

    public String getErrorMessage(){
        WebElement errorMessage = driver.findElement(By.cssSelector("#error>p"));
        return errorMessage.getText();
    }

    public void waitAtlassianErrorMessage() {
        waitUntilElementIsVisible(errorMsgAtlassian,10);
    }

    public String getAtlassianErrorMessage() {
        WebElement errorMessage = driver.findElement(By.xpath("//div[@id='login-error']//span"));
        return errorMessage.getText();

    }
}
